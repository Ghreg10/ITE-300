<?php 
	
	session_start();
	include 'config.php';


	// SAVE
	if(isset($_POST['save'])) {

		$task    = $_POST['task'];
		$deadline    = $_POST['deadline'];

		$save = mysqli_query($conn, "INSERT INTO tasktbl (task, deadline) VALUES ('$task', '$deadline')");
		if($save) {
	        $_SESSION['success']  = "Tasklist has been successfully saved!";
	        header("Location: index.php");                                
	    } else {
	      $_SESSION['exists'] = "Something went wrong while saving the task. Please try again.";
	      header("Location: index.php");
	    }

	}



	// DELETE
	if(isset($_POST['delete'])) {
		$Id = $_POST['Id'];

		$delete = mysqli_query($conn, "DELETE FROM tasktbl WHERE Id='$Id'");
		if($delete) {
			$_SESSION['success']  = "Tasklist has been deleted!";
	        header("Location: index.php");   
		} else {
			$_SESSION['exists'] = "Something went wrong while deleting the task. Please try again.";
            header("Location: index.php");
		}
	}

	



	// UPDATE
		if(isset($_POST['update'])) {
		$Id          = $_POST['Id'];
		$task    = $_POST['task'];
		$deadline    = $_POST['deadline'];

		$save = mysqli_query($conn, "UPDATE tasktbl SET task='$task', deadline='$deadline' WHERE Id='$Id'");
		if($save) {
	        $_SESSION['success']  = "Tasklist has been successfully updated!";
	        header("Location: index.php");                                
	    } else {
	      $_SESSION['exists'] = "Something went wrong while updating the task. Please try again.";
	      header("Location: index.php");
	    }

	}


?>
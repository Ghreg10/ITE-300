<?php session_start() ?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>CRUD</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
	<style>
		.modal-content{
    -webkit-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -moz-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -o-box-shadow: 0 5px 15px rgba(0,0,0,0);
    box-shadow: 0 5px 15px rgba(0,0,0,0);
}
	</style>
</head>
<body>
	
	<div class="container-fluid p-5">
		<h2 class="text-center">TASKLIST SYSTEM</h2>
		<div class="container p-5 bg-light rounded">

		  <?php if(isset($_SESSION['success'])) { ?> 
              <h5 class="alert text-success" role="alert"><b><?php echo $_SESSION['success']; ?></b></h5> 
          <?php unset($_SESSION['success']); } ?>


          <?php if(isset($_SESSION['invalid']) && isset($_SESSION['error'])) { ?>
              <h5 class="alert text-danger" role="alert"><b><?php echo $_SESSION['invalid']; ?> <?php echo $_SESSION['error']; ?></b></h5>
          <?php unset($_SESSION['invalid']);  unset($_SESSION['error']);  } ?>


          <?php  if(isset($_SESSION['exists'])) { ?>
              <h5 class="alert text-danger" role="alert"><b><?php echo $_SESSION['exists']; ?></b></h5>
          <?php unset($_SESSION['exists']); } ?>
			<button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal">Create New Task</button>
			<table class="table table-hover table-striped table-bordered" id="example">
				<thead>
					<tr>
						<th>No.</th>
						<th>Task</th>
						<th>Due-Date</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<?php 
							$i = 1;
							include 'config.php';
							$sql = mysqli_query($conn, "SELECT * FROM tasktbl");
							while ($row = mysqli_fetch_array($sql)) {
						?>
						<td><?php echo $i++; ?></td>
						<td><?php echo $row['task']; ?></td>
						<td><?php echo $row['deadline']; ?></td>
						<td>
							<button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#update<?php echo $row['Id']; ?>">Edit</button>
							<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?php echo $row['Id']; ?>">Delete</button>
						</td>
					</tr>
					<?php 
						include 'update.php';
						include 'delete.php';
					} ?>
				</tbody>
			</table>

		</div>
	</div>







	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Create new task</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <form action="processes.php" method="POST">
		      <div class="modal-body">
		        	<div class="form-group">
		        		<label for="">Task</label>
		        		<input type="text" class="form-control" name="task" placeholder="Enter your task..." required>
		        	</div>
		        	<div class="form-group mt-3">
		        		<label for="">Deadline</label>
		        		<input type="date" class="form-control" name="deadline" placeholder="Enter deadline..." required>
		        	</div>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
		        <button type="submit" name="save" class="btn btn-primary">Submit</button>
		      </div>
      </form>
	    </div>
	  </div>
	</div>

<style>
	body{
		background-color: #B0C4DE;
	}
	</style>


	<script src="js/bootstrap.bundle.min.js"></script>
	
</body>

<script>
  //-----------------------------ALERT TIMEOUT-------------------------//
  $(document).ready(function() {
      setTimeout(function() {
          $('.alert').hide();
      } ,3000);
  }
  );
//-----------------------------END ALERT TIMEOUT---------------------//
//
//
$(document).ready(function () {
    $('#example').DataTable();
});
</script>
</html>


